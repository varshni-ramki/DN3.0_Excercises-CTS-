package repository;

import com.example.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    
    // Derived query method to find employees by name
    List<Employee> findByName(String name);

    // Derived query method to find employees by email
    Employee findByEmail(String email);
    
    List<Employee> findByDepartmentName(String departmentName);
    
 // Custom query using @Query to find employees by email domain
    @Query("SELECT e FROM Employee e WHERE e.email LIKE %:domain")
    List<Employee> findEmployeesByEmailDomain(@Param("domain") String domain);
    
    // Named query methods
    List<Employee> findByName1(@Param("name") String name);

    List<Employee> findByEmail1(@Param("email") String email);
    
    // Custom query method to find employees by department name
    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);


}


