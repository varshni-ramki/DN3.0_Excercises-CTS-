package service;

import com.example.Department;
import repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    // Method to get all departments
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    // Method to get a department by ID
    public Optional<Department> getDepartmentById(Long id) {
        return departmentRepository.findById(id);
    }

    // Method to save a new or updated department
    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    // Method to delete a department by ID
    public void deleteDepartment(Long id) {
        departmentRepository.deleteById(id);
    }

    // Method to find departments by name
    public List<Department> findDepartmentsByName(String name) {
        return departmentRepository.findByName(name);
    }
}
