package service;

import com.example.Employee;
import 	repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Method to get all employees
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // Method to get an employee by ID
    public Optional<Employee> getEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    // Method to save a new or updated employee
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    // Method to delete an employee by ID
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    // Method to find employees by name
    public List<Employee> findEmployeesByName(String name) {
        return employeeRepository.findByName(name);
    }

    // Method to find an employee by email
    public Employee findEmployeeByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }
    // Testing custom queries
    public List<Employee> getEmployeesByDepartmentName(String departmentName) {
        return employeeRepository.findByDepartmentName(departmentName);
    }

    public List<Employee> getEmployeesByEmailDomain(String domain) {
        return employeeRepository.findEmployeesByEmailDomain(domain);
    }

    public List<Employee> getEmployeesByName(String name) {
        return employeeRepository.findByName(name);
    }

    @SuppressWarnings("unchecked")
	public Page<Employee> getEmployeesByEmail(String email) {
        return (Page<Employee>) employeeRepository.findByEmail(email);
    }
        
     // Method to get employees by department name with pagination
        public Page<Employee> getEmployeesByDepartmentName(String departmentName, Pageable pageable) {
            return employeeRepository.findByDepartmentName(departmentName, pageable);
    }
}
